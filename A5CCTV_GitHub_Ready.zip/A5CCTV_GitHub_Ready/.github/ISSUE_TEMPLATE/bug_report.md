---
name: Bug report
about: Report a problem with A5 CCTV
---

## Device

- Android version:
- Phone / TV / TV box:
- App version:

## Camera / NVR

- Manufacturer:
- Model:
- Connection: ONVIF / RTSP

## Problem

Describe what happened.

> Do not include camera passwords or other private credentials.
